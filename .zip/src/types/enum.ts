export const ItemType = { TASK: "TASK", COLUMN: "COLUMN" };
