export interface Boards {
  id: number;
  user_id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  deletedAt: string;
}
