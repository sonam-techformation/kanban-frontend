export interface NavbarProps {
  userName?: string;
}
