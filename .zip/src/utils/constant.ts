export const Constants = {
  API_URL: "http://localhost:8000",
};
