// import List from "../dashboard/list/[id]/page";

// interface PageProps {
//   params: Promise<{ id: number }>;
// }

// async function ServerList({ params }: PageProps) {
//   const { id } = await params;
//   console.log(id);
//   return <List id={id} />;
// }

// export default ServerList;
