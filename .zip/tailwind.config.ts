import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class", // Use class-based dark mode
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      // Customize your theme here
      colors: {
        primary: {
          light: "#4f46e5", // Light mode primary color
          dark: "#818cf8", // Dark mode primary color
        },
        background: {
          light: "#ffffff", // Light mode background
          dark: "#1f2937", // Dark mode background
        },
        text: {
          light: "#111827", // Light mode text color
          dark: "#f3f4f6", // Dark mode text color
        },
      },
    },
  },
  plugins: [],
};

export default config;
